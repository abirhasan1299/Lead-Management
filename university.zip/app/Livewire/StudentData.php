<?php

namespace App\Livewire;

use Livewire\Component;

class StudentData extends Component
{
    public function render()
    {
        return view('livewire.student-data');
    }
}
