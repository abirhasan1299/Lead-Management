<?php echo $__env->yieldContent("Enrollment"); ?>
<?php $__env->startSection('content'); ?>
    <table class="table table-bordered datatable">
       <tr>
           <th>Enrollment No</th>
           <th>Name</th>
           <th>Father Name</th>
           <th>Birth</th>
           <th>Programme</th>
           <th>Session</th>
           <th>Status</th>
       </tr>
        <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($e->enroll_number); ?></td>
                <td><?php echo e($e->name); ?></td>
                <td><?php echo e($e->father_name); ?></td>
                <td><?php echo e($e->dob); ?></td>
                <td><?php echo e($e->programme); ?></td>
                <td><?php echo e($e->session); ?></td>
                <td>
                    <span class="badge rounded-pill text-bg-<?php
                            if ($e->status == "Completed") {
                                echo "success";
                            } elseif ($e->status == "Pending") {
                                echo "warning";
                            } else {
                                echo "danger";
                            }
                        ?>">
                            <?php echo e($e->status); ?>

                    </span>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\projects\opjs-admin\resources\views/enrollment-list.blade.php ENDPATH**/ ?>