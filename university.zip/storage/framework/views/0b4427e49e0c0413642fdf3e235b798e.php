<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h2 class="mb-4">Edit Lead Information</h2>
        <form action="<?php echo e(route('lead.Edit',$data->id)); ?>" method="POST">
           <?php echo method_field("PUT"); ?>
            <?php echo csrf_field(); ?>
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="name" class="form-label">Name</label>
                    <input type="text" class="form-control" name="name" value="<?php echo e($data->name); ?>">
                </div>
                <div class="col-md-6">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" name="email" value="<?php echo e($data->email); ?>">
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-md-4">
                    <label class="form-label">Phone</label>
                    <input type="text" class="form-control" name="phone" value="<?php echo e($data->phone); ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Course</label>
                    <input type="text" class="form-control" name="course" value="<?php echo e($data->course); ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Unclear Paper</label>
                    <input type="text" class="form-control" name="unclearPaper" value="<?php echo e($data->unclearPaper); ?>">
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-md-4">
                    <label class="form-label">Enrolled Year</label>
                    <input type="text" class="form-control" name="enrolledYear"  value="<?php echo e($data->enrolledYear); ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Degree Purpose</label>
                    <input type="text" class="form-control" name="degreePurpose" value="<?php echo e($data->degreePurpose); ?>" >
                </div>
                <div class="col-md-4">
                    <label class="form-label">Date</label>
                    <input type="date" class="form-control" name="date" value="<?php echo e($data->date); ?>">
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-md-4">
                    <label class="form-label">User</label>
                    <select class="form-control" name="operation" id="">
                        <option  value="<?php echo e($data->operation); ?>" selected><?php echo e(ucfirst($data->admin->name)); ?></option>
                    <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option  value="<?php echo e($a->id); ?>"><?php echo e(ucfirst($a->name)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Next Follow-up</label>
                    <input type="date" class="form-control" name="nextfollowup" value="<?php echo e($data->nextfollowup); ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Status</label>
                    <select class="form-select" name="status">
                        <option value="<?php echo e($data->status); ?>" ><?php echo e(ucfirst($data->status)); ?></option>
                        <option value="live" >Live</option>
                        <option value="death" >Death</option>
                    </select>
                </div>
            </div>


            <div class="row mb-3">
                <div class="col-md-4">
                    <label class="form-label">Total Fees</label>
                    <input type="text" class="form-control" name="TotalFees" value="<?php echo e($data->TotalFees); ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Paid Fees</label>
                    <input type="text" class="form-control" name="paidFees" value="<?php echo e($data->paidFees); ?>">
                </div>
                <div class="col-md-4">
                    <label for="form-label" style="color:red;"> *Pending Fees*</label>
                    <input type="text" class="form-control"  value="<?php
                        if(empty((int)$data->TotalFees) && empty((int)$data->TotalFees))
                            {
                                echo "NONE";
                            }else{
                                echo ((int)$data->TotalFees -(int)$data->TotalFees);
                            }
                     ?>" readonly>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label">Reference</label>
                <input type="text" class="form-control" name="Reference" value="<?php echo e($data->Reference); ?>">
            </div>

            <button type="submit" class="btn btn-primary">Update Lead</button>
        </form>
        <br> <br>
        <h2 class="mb-4">Comments</h2>
        <!-- New Comment Form -->
        <form method="POST" action="<?php echo e(route('lead.addComment')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">

                <textarea placeholder="Add Comment" class="form-control" name="body" rows="3" required></textarea>
                <input type="hidden" name="lead" value="<?php echo e($data->id); ?>">
            </div>
            <button type="submit" class="btn btn-sm btn-success">Post</button>
        </form>
        <br>
        <!-- Comment List -->
        <?php if($data->commented->count()): ?>
            <ul class="list-group mt-3">
                <?php $__currentLoopData = $data->commented; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item d-flex justify-content-between align-items-start">
                        <div class="ms-2 me-auto">
                            <div class="fw-bold"><?php echo e($comment->created_at->diffForHumans()); ?></div>
                            <?php echo e($comment->comment); ?>

                        </div>
                        <div class="btn-group btn-group-sm">
                            <!-- Edit Button -->
                            <?php if($comment->created_at->gt(now()->subHours(24))): ?>
                                <!-- Show Edit only if comment is < 24 hours old -->
                                <button type="button" class="btn btn-outline-primary btn-sm" data-bs-toggle="modal" data-bs-target="#editCommentModal<?php echo e($comment->id); ?>">
                                    Edit
                                </button>
                            <?php endif; ?>

                            <!-- Delete Form -->
                            <form action="<?php echo e(route('comment.destroy',$comment->id)); ?>" method="POST" onsubmit="return confirm('Delete this comment?')" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-outline-danger btn-sm" type="submit">Delete</button>
                            </form>
                        </div>
                    </li>

                    <!-- Edit Modal -->
                    <div class="modal fade" id="editCommentModal<?php echo e($comment->id); ?>" tabindex="-1" aria-labelledby="editCommentLabel<?php echo e($comment->id); ?>" aria-hidden="true">
                        <div class="modal-dialog">
                            <form action="<?php echo e(route('comment.edit',$comment->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editCommentLabel<?php echo e($comment->id); ?>">Edit Comment</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <textarea class="form-control" name="comment" rows="3" required><?php echo e($comment->comment); ?></textarea>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary btn-sm">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <p class="text-muted mt-3">No comments yet.</p>
        <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Project\opjs\resources\views/edit-leads.blade.php ENDPATH**/ ?>