<?php echo $__env->yieldContent("Enrollment"); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-end">
    <div>
        <input type="search" id="searchInput" placeholder="Search">

    </div>
</div>-
<br>
    <table class="table table-bordered datatable" >
       <tr>
           <th>Enrollment No</th>
           <th>Name</th>
           <th>Father Name</th>
           <th>Birth</th>
           <th>Programme</th>
           <th>Session</th>
           <th>Status</th>
           <th>Action</th>
       </tr>
        <tbody id="myTable">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($e->enroll_number); ?></td>
                <td><?php echo e($e->name); ?></td>
                <td><?php echo e($e->father_name); ?></td>
                <td><?php echo e($e->dob); ?></td>
                <td><?php echo e($e->programme); ?></td>
                <td><?php echo e($e->session); ?></td>
                <td>
    <span class="badge rounded-pill" style="<?php
        switch($e->status) {
            case 'COMPLETED':
                echo 'background-color: #1ba94c; color: white;';
                break;
            case 'IN PROGRESS':
                echo 'background-color: #007acc; color: white;';
                break;
            case 'RE-APPEAR / BACKLOG':
                echo 'background-color: #f39c12; color: white;';
                break;
            case 'FAILED':
                echo 'background-color: #e74c3c; color: white;';
                break;
            case 'RESULT PENDING':
                echo 'background-color: #f4d03f; color: black;';
                break;
            case 'DISCONTINUED':
                echo 'background-color: #7f8e6d; color: white;';
                break;
            default:
                echo 'background-color: #6c757d; color: white;'; // default gray for unknown statuses
        }
    ?>">
        <?php echo e($e->status); ?>

    </span>
</td>
                <td>
                    <div class="d-flex justify-content-center">

                        <a href="<?php echo e(route('editStudent',$e->id)); ?>" role="button" class="btn btn-warning"><i class="bi bi-pencil-square"> </i></a>

                        <a href="<?php echo e(route('delStudent',$e->id)); ?>" class="btn btn-danger" role="button" style="margin-left:5px;"><i class="bi bi-trash " ></i></a>
                        
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<script>

    document.getElementById('searchInput').addEventListener('keyup', function() {
    let filter = this.value.toLowerCase();
    let rows = document.querySelectorAll('#myTable tr');

    rows.forEach(row => {
        let text = row.textContent.toLowerCase();
        if (text.indexOf(filter) > -1) {
        row.style.display = ''; // show row
        } else {
        row.style.display = 'none'; // hide row
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Project\enrollment\resources\views/enrollment-list.blade.php ENDPATH**/ ?>