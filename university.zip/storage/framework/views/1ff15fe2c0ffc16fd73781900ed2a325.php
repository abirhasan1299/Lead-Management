<?php echo $__env->yieldContent("Dashboard"); ?>
<?php $__env->startSection('content'); ?>
<h1>Dashbaord</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\projects\opjs-admin\resources\views/dashboard.blade.php ENDPATH**/ ?>