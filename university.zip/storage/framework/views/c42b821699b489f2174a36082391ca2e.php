<?php $__env->startSection('content'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
   <style>
        body {
            background-color: #f6f8fc;
            font-size: 15px;
            text-transform: uppercase;
        }

        .header {
            background: #fff;
            padding: 1rem 1.3rem;
            font-weight: 700;
            color: #0d3b66;
            box-shadow: 0 2px 6px rgba(0, 0, 0, .06);
        }


        table {
            min-width: 480px;
            font-size: 0.85rem;
        }

        thead {
            background-color: #0d3b66;
            color: white;
        }
    </style>

<div class="header text-center">OPJS UNIVERSITY – ADMIN RESULT UPLOAD</div>
<div class="container my-4">
    <div class="card p-4 mb-4">
        <h5 class="mb-3 text-uppercase text-primary">Verify & Upload</h5>

        <div class="d-flex justify-content-start mb-3">
            <div style="width: 60%">
                <input id="userId" class="form-control" placeholder="Enrollment Number">
                <input type="hidden" id="student_id" name="student_id">
            </div>
           <div style="width: 40%;margin-left: 3%;">
               <button  class="btn btn-primary" style="border-radius: 0px;" onclick="fetchUser()" >Verify</button>
           </div>
        </div>

        <div class="mb-3">
            <label>Student Name</label>
            <input id="sname" class="form-control" readonly>
        </div>
        <div class="mb-3">
            <label>Father's Name</label>
            <input id="fname" class="form-control" readonly>
        </div>
        <div class="mb-3">
            <label>Program</label>
            <input id="programme" class="form-control" readonly>
        </div>
        <div class="mb-3">
            <label>Session</label>
            <input id="session" class="form-control" readonly>
        </div>

        <div class="mb-3">
            <label>Mode</label>
            <select id="mode" class="form-select">
                <option value="Semester">SEMESTER</option>
                <option value="Year">YEAR</option>
                <option value="Combined">COMBINED SEMESTER</option>
            </select>
        </div>

        <div class="mb-3">
            <label>Status</label>
            <select id="status" class="form-select">
                <option>PASS</option>
                <option>FAIL</option>
                <option>REAPPEAR</option>
            </select>
        </div>

        <h6 class="mt-4 mb-2">Result Files</h6>
        <div id="fileContainer" class="mb-3"></div>
        <div class="d-flex justify-content-start">
            <button style="border-radius:0px;height: 40px;" class="btn btn-secondary mb-2" onclick="addFile()">+ Add File</button>

            <button class="btn btn-success" style="margin-left:2%;border-radius:0px;height: 40px;" onclick="save()" id="save-btn">Save</button>
        </div>
    </div>

    <div class="card p-4">
        <h5 class="mb-3 text-uppercase text-primary">Uploaded List</h5>
        <div class="table-responsive">
            <table class="table table-bordered" id="listTable">
                <thead>
                <tr>
                    <th>TERM</th>
                    <th>STATUS</th>
                    <th>RESULT</th>
                    <th>DELETE</th>
                </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
</div>

<script>
    // Define the modes
    const modes = {
        Semester: ['First Semester', 'Second Semester', 'Third Semester', 'Fourth Semester', 'Fifth Semester', 'Sixth Semester', 'Seventh Semester', 'Eighth Semester', 'Ninth Semester', 'Tenth Semester'],
        Year: ['First Year', 'Second Year', 'Third Year', 'Fourth Year'],
        Combined: ['1 & 2 Semester', '3 & 4 Semester', '5 & 6 Semester', '7 & 8 Semester', '9 & 10 Semester']
    };

    let fileCount = 0;

    // Listen for mode change
    $('#mode').on('change', function () {
        fileCount = 0; // Reset file counter
        $('#fileContainer').html(''); // Clear existing file rows
        addFile(); // Automatically add a new row based on new mode
    });

    // Add new file row
    function addFile() {
        const modeValue = $('#mode').val(); // Get selected mode
        const termOptions = modes[modeValue].map((term, index) => `<option ${index === fileCount ? 'selected' : ''}>${term}</option>`).join('');

        const fileRow = `
        <div class="row mb-2 align-items-center file-row">
            <div class="col-md-4 mb-2 mb-md-0">
                <select class="form-select termSelect">
                    ${termOptions}
                </select>
            </div>
            <div class="col-md-2 mb-2 mb-md-0">
                <select class="form-select statusSelect">
                    <option>PASS</option>
                    <option>FAIL</option>
                    <option>REAPPEAR</option>
                </select>
            </div>
            <div class="col-md-4 mb-2 mb-md-0">
                <input type="file" class="form-control">
            </div>
            <div class="col-md-2">
                <button class="btn btn-danger btn-sm" onclick="removeFile(this)">Delete</button>
            </div>
        </div>
    `;

        $('#fileContainer').append(fileRow);
        fileCount++;
    }

    // Remove file row
    function removeFile(button) {
        $(button).closest('.file-row').remove();
    }
    $('#save-btn').on('click', function() {
        $('#fileContainer').html('');
        fileCount = 0;
    });


</script>
   <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   <script>
       function fetchUser() {
           var userId = $('#userId').val();
           var csrfToken = $('meta[name="csrf-token"]').attr('content');

           $.ajax({
               url: "<?php echo e(route('admin.fetchEnroll')); ?>",
               method: "POST",
               data: { user_id: userId, _token: csrfToken },
               success: function(response) {
                   if (response.success) {
                       $('#sname').val(response.data.name);
                       $('#fname').val(response.data.father_name);
                       $('#programme').val(response.data.programme);
                       $('#session').val(response.data.session);
                       $('#student_id').val(response.data.id);

                   } else {

                       alert("No Data Found");

                   }
               },
               error: function() {
                   alert('Error fetching data.');
               }
           });
       }

       function renderResults(results) {
    let tbody = $('#listTable tbody');
    tbody.empty(); // Clear existing rows

    results.forEach(result => {
        // Create URL for file download/view
        let fileUrl = `/storage/${result.file_path}`;

        // Create table row HTML
        let row = `
            <tr>
                <td>${result.term}</td>
                <td>${result.status}</td>
                <td><a href="${fileUrl}" target="_blank">View Result</a></td>
                <td><button class="btn btn-danger btn-sm" onclick="deleteResult(${result.id})">Delete</button></td>
            </tr>
        `;

        tbody.append(row);
    });
}

       function fetchStudentFiles() {
           var userId = $('#student_id').val();
           var csrfToken = $('meta[name="csrf-token"]').attr('content');

           $.ajax({
               url: "<?php echo e(route('admin.fetchStudentFiles')); ?>",
               method: "POST",
               data: { user_id: userId, _token: csrfToken },
               success: function(response) {
                   if (response.success) {
                      renderResults(response.data);

                   } else {

                       alert("No Data Found");

                   }
               },
               error: function() {
                   alert('Error fetching data.');
               }
           });
       }
       
</script>

<script>
    function save() {
    var student_id = $('#student_id').val();
    if (!student_id) {
        alert('Please verify enrollment number first.');
        return;
    }

    var mode = $('#mode').val();
    var overall_status = $('#status').val();

    // Prepare files and metadata
    var formData = new FormData();
    formData.append('student_id', student_id);
    formData.append('mode', mode);
    formData.append('overall_status', overall_status);
    formData.append('_token', $('meta[name="csrf-token"]').attr('content'));

    // Collect all files, terms, and statuses
    $('.file-row').each(function(index, element) {
        var fileInput = $(element).find('input[type="file"]')[0];
        var term = $(element).find('.termSelect').val();
        var status = $(element).find('.statusSelect').val();

        if (fileInput.files.length === 0) {
            alert('Please select a file for all rows.');
            return false;
        }

        formData.append(`files[${index}]`, fileInput.files[0]);
        formData.append(`terms[${index}]`, term);
        formData.append(`statuses[${index}]`, status);
    });

    

    // AJAX request to save
    $.ajax({
        url: "<?php echo e(route('admin.uploadResults')); ?>",
        method: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            if (response.success) {
                alert('Files uploaded successfully!');
                fetchStudentFiles();
            } else {
                alert(response.message || 'Error uploading files.');
            }
        },
        error: function(xhr) {
            if (xhr.status === 422) {
                // Laravel validation error
                let errors = xhr.responseJSON.errors;
                let errorMessages = Object.values(errors).map(e => e.join(', ')).join('\n');
                alert('Validation error:\n' + errorMessages);
            } else {
                alert('An unexpected error occurred.');
                console.log(xhr);
            }
        }
    });
}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\enrollment\enrollment\resources\views/result.blade.php ENDPATH**/ ?>