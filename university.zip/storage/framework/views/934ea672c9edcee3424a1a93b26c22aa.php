
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Enrollment Verification – OPJS University</title>
  <style>
    :root{
      --primary:#004a8f;
      --primary-light:#007acc;
      --green:#1ba94c;
      --bg-grad:linear-gradient(135deg,#eaf3ff 0%,#f7fbff 100%);
      --text:#1c1c1c;
      --muted:#505050;
      --border:#e0e6ed;
    }
    body{
      margin:0;
      font-family:'Segoe UI',Helvetica,Arial,sans-serif;
      background:var(--bg-grad);
      display:flex;
      justify-content:center;
      align-items:center;
      min-height:100vh;
      padding:1rem;
    }
    .card{
      background:#ffffff;
      border-radius:18px;
      box-shadow:0 10px 28px rgba(0,42,85,.15);
      padding:2.8rem 3rem;
      width:460px;
      border-top:7px solid var(--primary);
    }
    .card h2{
      margin:0 0 2rem;
      font-size:1.45rem;
      color:var(--primary);
      text-align:center;
      letter-spacing:0.6px;
      text-transform:uppercase;
    }
    .row{
      display:flex;
      border-bottom:1px solid var(--border);
      padding:0.75rem 0;
      font-size:1.02rem;
    }
    .row:last-child{border-bottom:none;}
    .label{
      flex:0 0 48%;
      font-weight:600;
      color:var(--muted);
      text-transform:uppercase;
    }
    .value{
      flex:1;
      color:var(--text);
      font-weight:600;
      text-transform:uppercase;
    }
    .badge{
      display:inline-block;
      padding:0.25rem 0.7rem;

      color:#fff;
      border-radius:5px;
      font-size:0.9rem;
      font-weight:700;
      text-transform:uppercase;
    }
  </style>
</head>
<body>
  <div class="card">
    <h2>Enrollment Verification</h2>

    <div class="row"><div class="label">Enrollment No</div><div class="value"><?php echo e($data->enroll_number); ?></div></div>
    <div class="row"><div class="label">Student Name</div><div class="value"><?php echo e($data->name); ?></div></div>
    <div class="row"><div class="label">Father's Name</div><div class="value"><?php echo e($data->father_name); ?></div></div>
    <div class="row"><div class="label">Date of Birth</div><div class="value"><?php echo e($data->dob); ?></div></div>
    <div class="row"><div class="label">Programme</div><div class="value"><?php echo e($data->programme); ?></div></div>
    <div class="row"><div class="label">Session</div><div class="value"><?php echo e($data->session); ?></div></div>
    <div class="row"><div class="label">Status</div><div class="value"><span class="badge" style="background:<?php
        switch($data->status) {
            case 'COMPLETED':
                echo '#1ba94c';
                break;
            case 'IN PROGRESS':
                echo '#007acc';
                break;
            case 'RE-APPEAR / BACKLOG':
                echo '#f39c12';
                break;
            case 'FAILED':
                echo '#e74c3c';
                break;
            case 'RESULT PENDING':
                echo '#f4d03f';
                break;
            case 'DISCONTINUED':
                echo '#7f8e6d';
                break;
            default:
                echo '#6c757d'; 
        }
    ?> ;"><?php echo e($data->status); ?></span></div></div>
  </div>
</body>
</html>
<?php /**PATH /home/u655814061/domains/opjsuniversity.org.in/public_html/enrollment/resources/views/verification.blade.php ENDPATH**/ ?>