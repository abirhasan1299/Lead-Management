<?php $__env->startSection('content'); ?>
    <style>
        body {
            background-color: #f8f9fa;
        }
        .table-container {
            margin: 50px auto;
            max-width: 95%;
            background: #fff;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        thead th {
            background-color: #0d6efd;
            color: white;
            vertical-align: middle;
        }
    </style>
    <h3 class="mb-4">Leads List</h3>
    <table style="font-size: 14px;font-family: 'Poppins';" class="table table-bordered table-hover table-striped">
        <thead class="text-center">

        <tr>
            <th>SL</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>User</th>
            <th>Status</th>
            <th>Created At</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php
            $count = 1;
        ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($count++); ?></td>
                <td><?php echo e($d->name); ?></td>
                <td><?php echo e($d->email); ?></td>
                <td><?php echo e($d->phone); ?></td>
                <td><?php echo e(ucfirst($d->admin->name) ?? "None"); ?></td>
                <td>
                    <?php
                        if($d->status=='live')
                            {
                                echo '<span class="badge text-bg-success">Live</span>';
                            }
                        else{
                             echo '<span class="badge text-bg-danger">Dead</span>';
                        }
                    ?>
                </td>
                <td><?php echo e(date('d-m-Y',strtotime($d->date))); ?></td>

                <td class="d-flex justify-content-center">
                    <a href="<?php echo e(route('lead.edit',$d->id)); ?>" class="btn btn-sm btn-warning text-dark me-1">
                        <i class="bi bi-pencil-square"></i>
                    </a>
                    <?php if(session('role')==='admin'): ?>
                        <a href="<?php echo e(route('lead.delete',$d->id)); ?>" class="btn btn-sm btn-danger text-dark me-1">
                            <i class="bi bi-trash" style="color:white;"></i>
                        </a>
                    <?php endif; ?>
                </td>

            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Project\opjs\resources\views/filter.blade.php ENDPATH**/ ?>