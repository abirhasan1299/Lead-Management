<?php echo $__env->yieldContent("Add Enrollment "); ?>
<?php $__env->startSection('content'); ?>
<style>
    input, select, button {
        border-radius: 0 !important; /* Make all inputs, selects, and buttons square */
    }
</style>
<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Done !</strong> <?php echo e(session('success')); ?>.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
<div class="alert alert-danger" role="alert">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>



<div class="container mt-5">
    <h4 class="text-center mb-4">Enrollment Submission</h4>
    <form method="post" action="<?php echo e(route('enrollDone')); ?>" autocomplete="off">
        <?php echo csrf_field(); ?>
        <div class="row mb-3">
            <div class="col-md-6 mb-3 mb-md-0">
                <label for="enrollmentNumber" class="form-label">Enrollment  Number</label>
                <input type="text" name="enroll_number" class="form-control" id="enrollmentNumber" placeholder="Enter  Number" required>
            </div>
            <div class="col-md-6">
                <label for="studentName" class="form-label">Student Name</label>
                <input type="text" name="name" class="form-control" id="studentName" placeholder="Enter Student Name" required>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6 mb-3 mb-md-0">
                <label for="fatherName" class="form-label">Father's Name</label>
                <input type="text" name="father_name" class="form-control" id="fatherName" placeholder="Enter Father's Name" required>
            </div>
            <div class="col-md-6">
                <label for="dob" class="form-label">Date of Birth</label>
                <input type="date" name="dob" class="form-control" id="dob" required>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6 mb-3 mb-md-0">
                <label for="programme" class="form-label">Programme</label>
                <input type="text" name="programme" class="form-control" id="programme" placeholder="Enter Programme Name" required>
            </div>
            <div class="col-md-6">
                <label for="session" class="form-label">Session</label>
                <input type="text" name="session" class="form-control" id="session" placeholder="e.g. 2021 - 2025" required>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6 mb-3 mb-md-0">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" name="status" required>
                    <option selected disabled>------Select Status------</option>
                    <option value="Completed">Completed</option>
                    <option value="Pending">Pending</option>
                    <option value="Rejected">Rejected</option>
                </select>
            </div>
            <div class="col-md-6">
                <div class="d-flex justify-content-start">
                    <div style="margin-top: 35px;width: 30%;" class="d-grid">
                        <button type="submit" class="btn btn-primary"> ADD </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\projects\opjs-admin\resources\views/add-enrollment.blade.php ENDPATH**/ ?>