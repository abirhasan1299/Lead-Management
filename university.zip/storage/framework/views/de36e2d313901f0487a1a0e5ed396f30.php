<?php $__env->startSection('content'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
   <style>
        body {
            background-color: #f6f8fc;
            font-size: 15px;
            text-transform: uppercase;
        }

        .header {
            background: #fff;
            padding: 1rem 1.3rem;
            font-weight: 700;
            color: #0d3b66;
            box-shadow: 0 2px 6px rgba(0, 0, 0, .06);
        }


        table {
            min-width: 480px;
            font-size: 0.85rem;
        }

        thead {
            background-color: #0d3b66;
            color: white;
        }
    </style>

<div class="header text-center">OPJS UNIVERSITY – ADMIN RESULT UPLOAD</div>
<div class="container my-4">
    <div class="card p-4 mb-4">
        <h5 class="mb-3 text-uppercase text-primary">Verify & Upload</h5>

        <div class="d-flex justify-content-start mb-3">
            <div style="width: 60%">
                <input id="userId" class="form-control" placeholder="Enrollment Number">
                <input type="hidden" id="student_id" name="student_id">
            </div>
           <div style="width: 40%;margin-left: 3%;">
               <button  class="btn btn-primary" style="border-radius: 0px;" onclick="fetchUser()" >Verify</button>
           </div>
        </div>

        <div class="mb-3">
            <label>Student Name</label>
            <input id="sname" class="form-control" readonly>
        </div>
        <div class="mb-3">
            <label>Father's Name</label>
            <input id="fname" class="form-control" readonly>
        </div>
        <div class="mb-3">
            <label>Program</label>
            <input id="programme" class="form-control" readonly>
        </div>
        <div class="mb-3">
            <label>Session</label>
            <input id="session" class="form-control" readonly>
        </div>

        <div class="mb-3">
            <label>Mode</label>
            <select id="mode" class="form-select">
                <option value="Semester">SEMESTER</option>
                <option value="Year">YEAR</option>
                <option value="Combined">COMBINED SEMESTER</option>
            </select>
        </div>

        <div class="mb-3">
            <label>Status</label>
            <select id="status" class="form-select">
                <option>PASS</option>
                <option>FAIL</option>
                <option>REAPPEAR</option>
            </select>
        </div>

        <h6 class="mt-4 mb-2">Result Files</h6>
        <div id="fileContainer" class="mb-3"></div>
        <div class="d-flex justify-content-start">
            <button style="border-radius:0px;height: 40px;" class="btn btn-secondary mb-2" onclick="addFile()">+ Add File</button>

            <button class="btn btn-success" style="margin-left:2%;border-radius:0px;height: 40px;" onclick="if(save()){ EmptyFileRow(); }">Save</button>
        </div>
    </div>

    <div class="card p-4">
        <h5 class="mb-3 text-uppercase text-primary">Uploaded List</h5>
        <div class="table-responsive">
            <table class="table table-bordered" id="listTable">
                <thead>
                <tr>
                    <th>TERM</th>
                    <th>STATUS</th>
                    <th>RESULT</th>
                    <th>DELETE</th>
                </tr>
                </thead>
                <tbody>
                    <tr id="msg"></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php echo $__env->make('js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Project\opjs\resources\views/result.blade.php ENDPATH**/ ?>