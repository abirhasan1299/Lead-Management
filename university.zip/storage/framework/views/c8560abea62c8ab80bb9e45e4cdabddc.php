
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Verification – OPJS University</title>

  <style>
    body{font-family: Arial, sans-serif;background:#f5f7fa;display:flex;justify-content:center;align-items:center;min-height:100vh;margin:0;padding:2rem}
    .verify-card{background:#fff;padding:2rem 2.5rem;border-radius:12px;box-shadow:0 4px 14px rgba(0,0,0,0.1);width:420px}
    h2{text-align:center;margin-bottom:1.2rem;color:#004a8f}
    label{display:block;margin:0.75rem 0 0.25rem;font-weight:600}
    input[type="text"],input[type="date"]{width:100%;padding:0.6rem;border:1px solid #ccc;border-radius:6px}
    button{margin-top:1rem;width:100%;padding:0.75rem;border:none;border-radius:6px;background:#004a8f;color:#fff;font-size:1rem;cursor:pointer}
    button:hover{background:#003871}
    .msg{margin-top:1rem;font-weight:600;text-align:center}
    .result{margin-top:1rem;border-top:1px solid #ddd;padding-top:1rem}
    .result span{display:block;margin:0.25rem 0}
    .msg {
  margin-top: 1rem;
  font-weight: 600;
  text-align: center;
}
  </style><script type="text/javascript">
      var onloadCallback = function() {
        grecaptcha.render('html_element', {
          'sitekey' : '6LeZFHMrAAAAAFsbsd6zzW0w5M29sTR4NcwwzKcS'
        });
      };
    </script>
  <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>
<body>

  <div class="verify-card">
    <h2>Enrollment Verification</h2>

    <?php if(session('invalid')): ?>
            <div class="msg" style="color: #d93025;"> <!-- Google-style red error -->
                <?php echo e(session('invalid')); ?>

            </div>
    <?php endif; ?>
<style>
  /* Container wrapping your form and loading message */
  #formContainer {
    position: relative;
    width: 100%;
    max-width: 400px; /* or your form width */
    margin: 0 auto;
  }

  #loadingMessage {
    display: none; /* hide initially */
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(255, 255, 255, 0.9); /* white translucent overlay */
    z-index: 10;

    display: flex;  /* flex for centering */
    flex-direction: row;
    align-items: center;
    justify-content: center;
    gap: 12px;

    font-weight: 600;
    font-size: 1.25rem;
    color: #0052cc;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }

  .spinner {
    width: 24px;
    height: 24px;
    border: 3px solid #cce0ff;
    border-top: 3px solid #0052cc;
    border-radius: 50%;
    animation: spin 1s linear infinite;
  }

  @keyframes spin {
    to { transform: rotate(360deg); }
  }
</style>

<div id="formContainer">
  <form id="verifyForm" method="post" action="<?php echo e(route('enrollment-verify')); ?>" autocomplete="off">
    <?php echo csrf_field(); ?>
    <label>Enrollment Number</label>
    <input type="text" name="enrollment" maxlength="20" placeholder="e.g. DN15755001" required>

    <label>Date of Birth</label>
    <input type="date" name="dob" required>

    <div style="margin-top:1rem" id="html_element" class="g-recaptcha"
         data-sitekey="6LeZFHMrAAAAAFsbsd6zzW0w5M29sTR4NcwwzKcS"></div>

    <button id="submitBtn" type="submit">Verify Student</button>
  </form>

  <div id="loadingMessage">
    <div class="spinner"></div>
    Verifying...
  </div>
</div>
 <script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit"
        async defer>
    </script>
<script>
  const form = document.getElementById('verifyForm');
  const submitBtn = document.getElementById('submitBtn');
  const loadingMessage = document.getElementById('loadingMessage');

  loadingMessage.style.display = 'none'; // ensure hidden at start

  form.addEventListener('submit', function(event) {
    event.preventDefault();
    submitBtn.disabled = true;
    loadingMessage.style.display = 'flex'; // show centered overlay

    setTimeout(() => {
      form.submit();
    }, 3000);
  });
</script>






  </div>

</body>
</html>
<?php /**PATH /home/u655814061/domains/opjsuniversity.org.in/public_html/enrollment/resources/views/enroll-form.blade.php ENDPATH**/ ?>