<?php echo $__env->yieldContent("Update Enrollment "); ?>
<?php $__env->startSection('content'); ?>
<style>
    input, select, button {
        border-radius: 0 !important; /* Make all inputs, selects, and buttons square */
    }
</style>


<?php if($errors->any()): ?>
<div class="alert alert-danger" role="alert">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>



<div class="container mt-5">
    <h4 class="text-center mb-4">Enrollment Update Form</h4>
    <form method="post" action="<?php echo e(route('updateStudent',$data->id)); ?>" autocomplete="off">
        <?php echo csrf_field(); ?>
        <div class="row mb-3">
            <div class="col-md-6 mb-3 mb-md-0">
                <label for="enrollmentNumber" class="form-label">Enrollment  Number</label>
                <input type="text" name="enroll_number" class="form-control" id="enrollmentNumber" value="<?php echo e($data->enroll_number); ?>" required>
            </div>
            <div class="col-md-6">
                <label for="studentName" class="form-label">Student Name</label>
                <input type="text" name="name" class="form-control" id="studentName" value="<?php echo e($data->name); ?>" required>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6 mb-3 mb-md-0">
                <label for="fatherName" class="form-label">Father's Name</label>
                <input type="text" name="father_name" class="form-control" id="fatherName" value="<?php echo e($data->father_name); ?>" required>
            </div>
            <div class="col-md-6">
                <label for="dob" class="form-label">Date of Birth</label>
                <input type="date" name="dob" class="form-control" id="dob" value="<?php echo e($data->dob); ?>" required>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6 mb-3 mb-md-0">
                <label for="programme" class="form-label">Programme</label>
                <input type="text" name="programme" class="form-control" id="programme" value="<?php echo e($data->programme); ?>" required>
            </div>
            <div class="col-md-6">
                <label for="session" class="form-label">Session</label>
                <input type="text" name="session" class="form-control" id="session" value="<?php echo e($data->session); ?>" required>
            </div>
        </div>

        <div class="row mb-3">
           <div class="col-md-6 mb-3 mb-md-0">
    <label for="status" class="form-label">Status</label>
    <select class="form-select" name="status" required>
        <option selected value="<?php echo e($data->session); ?>"><?php echo e($data->status); ?></option>
        <option value="COMPLETED" style="color: #1ba94c">COMPLETED</option>
        <option value="IN PROGRESS" style="color: #007acc">IN PROGRESS</option>
        <option value="RE-APPEAR / BACKLOG" style="color: #f39c12">RE-APPEAR / BACKLOG</option>
        <option value="FAILED" style="color: #e74c3c">FAILED</option>
        <option value="RESULT PENDING" style="color: #f4d03f">RESULT PENDING</option>
        <option value="DISCONTINUED" style="color: #7f8e6d">DISCONTINUED</option>
    </select>
</div>
            <div class="col-md-6">
                <div class="d-flex justify-content-start">
                    <div style="margin-top: 35px;width: 30%;" class="d-grid">
                        <button type="submit" class="btn btn-danger"> UPDATE </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u655814061/domains/opjsuniversity.org.in/public_html/enrollment/resources/views/edit-student.blade.php ENDPATH**/ ?>