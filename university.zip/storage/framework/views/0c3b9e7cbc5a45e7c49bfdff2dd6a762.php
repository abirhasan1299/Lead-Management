
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Student Result | OPJS University</title>
    <link href='https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap' rel='stylesheet'>
    <style>
        :root{
            --primary:#0d3b66;
            --accent:#1e6fe3;
            --success:#28a745;
            --danger:#dc3545;
            --bg:#f7fafc;
            --text:#27303f;
            --muted:#5d6778;
            --border:#e1e7ef;
        }
        *{box-sizing:border-box;margin:0;padding:0}
        body{font-family:'Roboto',Arial,sans-serif;background:var(--bg);color:var(--text);line-height:1.6}
        .navbar{background:#fff;box-shadow:0 2px 6px rgba(0,0,0,.07);display:flex;justify-content:center;align-items:center;padding:1rem 1.5rem}
        .navbar span{font-weight:700;color:var(--primary);font-size:1.05rem;letter-spacing:.6px;text-transform:uppercase}
        .container{max-width:960px;margin:2.5rem auto;padding:0 1rem}
        .section-title{font-size:1.2rem;font-weight:700;color:var(--primary);margin-bottom:1rem;text-transform:uppercase;letter-spacing:.5px}
        .profile-card{background:#fff;border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,.06);padding:2rem 2.5rem;margin-bottom:2.5rem}
        .profile-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:1.2rem 2rem}
        .field-label{font-size:.78rem;color:var(--muted);font-weight:600;text-transform:uppercase}
        .field-value{font-size:.95rem;font-weight:600;color:var(--text);text-transform:uppercase}
        .badge{color:#fff;padding:.25rem .7rem;border-radius:4px;font-weight:700;font-size:.8rem;text-transform:uppercase}
        .table-wrap{background:#fff;border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,.06);overflow-x:auto}
        table{width:100%;border-collapse:collapse;min-width:550px}
        thead{background:var(--primary);color:#fff}
        th,td{padding:1rem 1.2rem;font-size:.88rem;text-align:left;border-bottom:1px solid var(--border)}
        tbody tr:nth-child(odd){background:#f1f5fb}
        tbody tr:hover{background:#e8f0ff}
        td.status-pass{color:var(--success);font-weight:600;text-transform:uppercase}
        td.status-fail{color:var(--danger);font-weight:600;text-transform:uppercase}
        td.status-reappear{color:var(--muted);font-weight:600;text-transform:uppercase}
        .download-btn{background:var(--accent);color:#fff;padding:.5rem 1rem;border-radius:6px;font-size:.82rem;font-weight:600;text-decoration:none;white-space:nowrap}
        .download-btn:hover{background:#1457c4}
        @media(max-width:600px){
            .download-btn{display:inline-block;width:100%;text-align:center;margin-top:.4rem}
        }
    </style>
</head>
<body>

<nav class='navbar'><span>OPJS UNIVERSITY – Result Portal</span></nav>

<div class='container'>

    <!-- summary -->
    <h2 class='section-title'>Student Summary</h2>
    <div class='profile-card'>
        <div class='profile-grid'>
            <div><div class='field-label'>Student Name</div><div class='field-value'><?php echo e($student->name); ?></div></div>
            <div><div class='field-label'>Enrollment Number</div><div class='field-value'><?php echo e($student->enroll_number); ?></div></div>
            <div><div class='field-label'>Programme</div><div class='field-value'><?php echo e($student->programme); ?></div></div>
            <div><div class='field-label'>Session</div><div class='field-value'><?php echo e($student->session); ?></div></div>
            <div>
                <div class='field-label'>Overall Status</div>
                <div class='field-value'>
                    <span class='badge' style="<?php
        switch($student->status) {
            case 'COMPLETED':
                echo 'background-color: #1ba94c; color: white;';
                break;
            case 'IN PROGRESS':
                echo 'background-color: #007acc; color: white;';
                break;
            case 'RE-APPEAR / BACKLOG':
                echo 'background-color: #f39c12; color: white;';
                break;
            case 'FAILED':
                echo 'background-color: #e74c3c; color: white;';
                break;
            case 'RESULT PENDING':
                echo 'background-color: #f4d03f; color: black;';
                break;
            case 'DISCONTINUED':
                echo 'background-color: #7f8e6d; color: white;';
                break;
            default:
                echo 'background-color: #6c757d; color: white;'; // default gray for unknown statuses
        }
    ?>"><?php echo e($student->status); ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- results -->
    <h2 class='section-title'>Semester Results</h2>
    <div class='table-wrap'>
        <table>
            <thead>
            <tr><th>Term</th><th>Status</th><th style='width:150px;text-align:center'>Download</th></tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($d->term); ?></td>
                <td class='<?php
                            if($d->status=="PASS")
                                {
                                    echo "status-pass";
                                }elseif ($d->status=="FAIL")
                                {
                                    echo "status-fail";
                                }else{
                                    echo "status-reappear";
                                }
                         ?>'><?php echo e($d->status); ?></td>
                <td style='text-align:center'><a class='download-btn' href="<?php echo e(asset('storage/'.$d->file_path)); ?>" download>Download PDF</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

</div>

</body>
</html>
<?php /**PATH F:\Project\opjs\resources\views/public-result.blade.php ENDPATH**/ ?>